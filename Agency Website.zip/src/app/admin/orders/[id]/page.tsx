import type { Metadata } from "next"
import { redirect } from "next/navigation"
import { auth } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { DashboardShell } from "@/components/dashboard/admin-shell"
import { DashboardHeader } from "@/components/dashboard/header"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"

export const dynamic = "force-dynamic"

export const metadata: Metadata = {
  title: "Order Details | Uptix Digital",
  description: "View order details and manage status.",
}

export default async function AdminOrderDetailPage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = await params
  
  const session = await auth()

  if (!session?.user || session.user.role !== "ADMIN") {
    redirect("/auth/login")
  }

  if (!id) {
    redirect("/admin/orders")
  }

  const order = await prisma.order.findUnique({
    where: { id },
    include: {
      user: true,
      payments: {
        orderBy: { createdAt: "desc" },
      },
    },
  })

  if (!order) {
    redirect("/admin/orders")
  }

  const statusColors: Record<string, string> = {
    PENDING: "bg-yellow-500/10 text-yellow-400",
    IN_PROGRESS: "bg-blue-500/10 text-blue-400",
    REVIEW: "bg-purple-500/10 text-purple-400",
    DONE: "bg-green-500/10 text-green-400",
    CANCELLED: "bg-red-500/10 text-red-400",
  }

  return (
    <DashboardShell>
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Link href="/admin/orders">
            <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Orders
            </Button>
          </Link>
        </div>

        <DashboardHeader
          heading={order.title}
          text="View and manage this order."
        />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Details */}
          <div className="lg:col-span-2 space-y-6">
            <Card className="glass-card border-white/10">
              <CardHeader>
                <CardTitle className="text-white">Order Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-slate-400 text-sm">Status</p>
                    <Badge className={statusColors[order.status]} style={{ width: "fit-content" }}>
                      {order.status.replace("_", " ")}
                    </Badge>
                  </div>
                  <div>
                    <p className="text-slate-400 text-sm">Service Type</p>
                    <p className="text-white font-medium">{order.serviceType.replace(/_/g, " ")}</p>
                  </div>
                  <div>
                    <p className="text-slate-400 text-sm">Created</p>
                    <p className="text-white">{new Date(order.createdAt).toLocaleString()}</p>
                  </div>
                  <div>
                    <p className="text-slate-400 text-sm">Budget</p>
                    <p className="text-white font-mono">${order.budget || "Not specified"}</p>
                  </div>
                  <div>
                    <p className="text-slate-400 text-sm">Timeline</p>
                    <p className="text-white">{order.timeline || "Not specified"}</p>
                  </div>
                  <div>
                    <p className="text-slate-400 text-sm">Payments Made</p>
                    <p className="text-white font-mono text-lg">
                      ${order.payments.reduce((s, p) => s + p.amount, 0).toFixed(2)}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="glass-card border-white/10">
              <CardHeader>
                <CardTitle className="text-white">Description</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-300 whitespace-pre-wrap">{order.description}</p>
              </CardContent>
            </Card>

            {order.payments.length > 0 && (
              <Card className="glass-card border-white/10">
                <CardHeader>
                  <CardTitle className="text-white">Payments</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {order.payments.map((payment) => (
                      <div key={payment.id} className="flex justify-between items-center py-2 border-b border-white/5 last:border-0">
                        <div>
                          <p className="text-white text-sm">${payment.amount.toFixed(2)}</p>
                          <p className="text-slate-400 text-xs">{payment.method || "Bank Transfer"}</p>
                        </div>
                        <div className="text-right">
                          <Badge className={
                            payment.status === "COMPLETED"
                              ? "bg-green-500/10 text-green-400"
                              : payment.status === "PENDING"
                                ? "bg-yellow-500/10 text-yellow-400"
                                : "bg-red-500/10 text-red-400"
                          }>
                            {payment.status}
                          </Badge>
                          <p className="text-slate-400 text-xs mt-1">
                            {new Date(payment.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Client Info Sidebar */}
          <Card className="glass-card border-white/10 h-fit">
            <CardHeader>
              <CardTitle className="text-white text-base">Client Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="text-slate-400 text-sm">Name</p>
                <p className="text-white font-medium">{order.user.name || "Not provided"}</p>
              </div>
              <div>
                <p className="text-slate-400 text-sm">Email</p>
                <p className="text-white break-all">{order.user.email}</p>
              </div>

              <div className="pt-4 border-t border-white/10">
                <Link href={`/admin/users/${order.user.id}`}>
                  <Button variant="outline" className="w-full border-white/10 text-slate-400 hover:text-white">
                    View Client Profile
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardShell>
  )
}
