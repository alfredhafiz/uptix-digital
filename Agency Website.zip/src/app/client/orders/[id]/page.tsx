import type { Metadata } from "next"
import { redirect } from "next/navigation"
import { auth } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { DashboardShell } from "@/components/dashboard/shell"
import { DashboardHeader } from "@/components/dashboard/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"

export const dynamic = "force-dynamic"

export const metadata: Metadata = {
  title: "Order Details | Uptix Digital",
  description: "View your order details and status.",
}

export default async function ClientOrderDetailPage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = await params
  
  const session = await auth()

  if (!session?.user) {
    redirect("/auth/login")
  }

  if (!id) {
    redirect("/client/orders")
  }

  const order = await prisma.order.findUnique({
    where: { id },
    include: {
      user: true,
      payments: {
        orderBy: { createdAt: "desc" },
      },
    },
  })

  if (!order) {
    redirect("/client/orders")
  }

  // Verify ownership
  if (order.userId !== session.user.id) {
    redirect("/client/orders")
  }

  const statusColors: Record<string, string> = {
    PENDING: "bg-yellow-500/10 text-yellow-400",
    IN_PROGRESS: "bg-blue-500/10 text-blue-400",
    REVIEW: "bg-purple-500/10 text-purple-400",
    DONE: "bg-green-500/10 text-green-400",
    CANCELLED: "bg-red-500/10 text-red-400",
  }

  const statusSteps = ["PENDING", "IN_PROGRESS", "REVIEW", "DONE"]
  const currentStep = statusSteps.indexOf(order.status)

  return (
    <DashboardShell>
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Link href="/client/orders">
            <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Orders
            </Button>
          </Link>
        </div>

        <DashboardHeader
          heading={order.title}
          text="Track your project progress."
        />

        {/* Progress Timeline */}
        <Card className="glass-card border-white/10">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between relative">
              <div className="absolute top-1/2 left-0 right-0 h-1 bg-white/10 -z-10" />
              {statusSteps.map((step, index) => (
                <div
                  key={step}
                  className="flex flex-col items-center gap-2 relative"
                >
                  <div
                    className={`w-10 h-10 rounded-full border-2 flex items-center justify-center font-bold text-sm ${
                      index <= currentStep
                        ? "bg-blue-500 border-blue-400 text-white"
                        : "bg-white/5 border-white/20 text-slate-400"
                    }`}
                  >
                    {index + 1}
                  </div>
                  <span className="text-xs text-slate-400 whitespace-nowrap mt-2">
                    {step.replace("_", " ")}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Details */}
          <div className="lg:col-span-2 space-y-6">
            <Card className="glass-card border-white/10">
              <CardHeader>
                <CardTitle className="text-white">Order Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-slate-400 text-sm">Status</p>
                    <Badge className={statusColors[order.status]} style={{ width: "fit-content" }}>
                      {order.status.replace("_", " ")}
                    </Badge>
                  </div>
                  <div>
                    <p className="text-slate-400 text-sm">Service Type</p>
                    <p className="text-white font-medium">{order.serviceType.replace(/_/g, " ")}</p>
                  </div>
                  <div>
                    <p className="text-slate-400 text-sm">Created</p>
                    <p className="text-white">{new Date(order.createdAt).toLocaleDateString()}</p>
                  </div>
                  <div>
                    <p className="text-slate-400 text-sm">Budget</p>
                    <p className="text-white font-mono">${order.budget || "Not specified"}</p>
                  </div>
                  <div>
                    <p className="text-slate-400 text-sm">Timeline</p>
                    <p className="text-white">{order.timeline || "Not specified"}</p>
                  </div>
                  <div>
                    <p className="text-slate-400 text-sm">Payments Made</p>
                    <p className="text-white font-mono text-lg">
                      ${order.payments.reduce((s, p) => s + p.amount, 0).toFixed(2)}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="glass-card border-white/10">
              <CardHeader>
                <CardTitle className="text-white">Project Description</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-300 whitespace-pre-wrap">{order.description}</p>
              </CardContent>
            </Card>

            {order.status !== "DONE" && order.status !== "CANCELLED" && (
              <Card className="glass-card border-blue-500/20 border-l-4 border-l-blue-500">
                <CardHeader>
                  <CardTitle className="text-white text-base">Next Steps</CardTitle>
                </CardHeader>
                <CardContent className="text-slate-300 text-sm space-y-2">
                  {order.status === "PENDING" && (
                    <p>Our team is reviewing your project requirements. We'll start development soon and keep you updated.</p>
                  )}
                  {order.status === "IN_PROGRESS" && (
                    <p>Your project is actively being developed. Check back for updates on progress.</p>
                  )}
                  {order.status === "REVIEW" && (
                    <p>Your project is in the review phase. We're testing and ensuring quality before final delivery.</p>
                  )}
                </CardContent>
              </Card>
            )}

            {order.payments.length > 0 && (
              <Card className="glass-card border-white/10">
                <CardHeader>
                  <CardTitle className="text-white">Payment History</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {order.payments.map((payment) => (
                      <div key={payment.id} className="flex justify-between items-center py-3 border-b border-white/5 last:border-0">
                        <div>
                          <p className="text-white font-medium">${payment.amount.toFixed(2)}</p>
                          <p className="text-slate-400 text-xs">{payment.method || "Bank Transfer"}</p>
                        </div>
                        <div className="text-right">
                          <Badge className={
                            payment.status === "COMPLETED"
                              ? "bg-green-500/10 text-green-400"
                              : payment.status === "PENDING"
                                ? "bg-yellow-500/10 text-yellow-400"
                                : "bg-red-500/10 text-red-400"
                          }>
                            {payment.status}
                          </Badge>
                          <p className="text-slate-400 text-xs mt-1">
                            {new Date(payment.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Actions Sidebar */}
          <div className="space-y-4">
            <Card className="glass-card border-white/10">
              <CardHeader>
                <CardTitle className="text-white text-base">Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Link href={`/client/messages?orderId=${order.id}`}>
                  <Button className="w-full bg-blue-600 hover:bg-blue-700">
                    Message Team
                  </Button>
                </Link>
                {order.status !== "DONE" && order.status !== "CANCELLED" && order.budget && order.budget > 0 && (
                  <Link href={`/client/payment?orderId=${order.id}`}>
                    <Button variant="outline" className="w-full border-white/10 text-slate-300 hover:text-white">
                      Make Payment
                    </Button>
                  </Link>
                )}
                <Link href="/client/invoices">
                  <Button variant="outline" className="w-full border-white/10 text-slate-300 hover:text-white">
                    View Invoices
                  </Button>
                </Link>
              </CardContent>
            </Card>

            {order.status === "DONE" && (
              <Card className="glass-card border-green-500/20 border-l-4 border-l-green-500">
                <CardContent className="pt-6">
                  <p className="text-green-400 text-sm font-medium">Congratulations! Your project is complete.</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </DashboardShell>
  )
}
