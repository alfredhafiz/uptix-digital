# 🚀 Advanced Enhancements Configuration Guide

## Overview
This guide covers setup and configuration for all optional enhancements:
1. **2FA/MFA** - Two-Factor Authentication
2. **Algolia Search** - Full-text search
3. **Sentry** - Error tracking
4. **Swagger** - API documentation
5. **New Relic** - Performance monitoring

---

## 1️⃣ **Two-Factor Authentication (2FA/MFA)**

### What is 2FA?
Users can enable Time-based One-Time Password (TOTP) authentication for added security.

### Setup Steps

#### Install Dependencies
```bash
npm install speakeasy qrcode
npm install --save-dev @types/speakeasy
```

#### Environment Variables
Add to `.env.production`:
```env
# 2FA Configuration (optional)
TWO_FACTOR_ENABLED=true
TWO_FACTOR_WINDOW=2  # Allow 2 time windows for drift
```

#### Database Setup
Update Prisma schema to add 2FA fields to User model:
```prisma
model User {
  // ... existing fields ...
  twoFactorEnabled    Boolean   @default(false)
  twoFactorSecret     String?   @encrypted  // Requires Prisma field encryption
  twoFactorBackupCodes Json?    // Store as JSON array
}
```

#### API Endpoints
- `POST /api/user/two-factor/setup` - Generate 2FA secret
  - Returns: QR code, secret, backup codes

- `POST /api/user/two-factor/verify` - Enable 2FA
  - Body: `{ token, secret, backupCodes }`

#### Test Locally
```bash
# 1. Start app
npm run dev

# 2. Call setup endpoint
curl -X POST http://localhost:3000/api/user/two-factor/setup \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"

# 3. Scan QR code with authenticator app (Google Authenticator, Authy, etc)

# 4. Get 6-digit code from app and verify
curl -X POST http://localhost:3000/api/user/two-factor/verify \
  -H "Content-Type: application/json" \
  -d '{"token":"123456","secret":"...","backupCodes":[...]}'
```

### Authenticator Apps to Test
- Google Authenticator
- Microsoft Authenticator
- Authy
- 1Password

---

## 2️⃣ **Algolia Full-Text Search**

### What is Algolia?
Blazingly fast search service with autocomplete, faceting, and analytics.

### Setup Steps

#### Get API Keys
1. Go to https://www.algolia.com/
2. Sign up for free account
3. Create new application
4. Get AppID and API Keys from dashboard
5. You need 2 keys:
   - **Admin API Key** - For indexing (server-side)
   - **Search API Key** - For searching (public, safe)

#### Install Dependencies
```bash
npm install algoliasearch
npm install --save-dev @types/algoliasearch
```

#### Environment Variables
Add to `.env.production`:
```env
# Algolia Search Configuration
ALGOLIA_APP_ID=YOUR_APP_ID
ALGOLIA_API_KEY=YOUR_ADMIN_API_KEY
ALGOLIA_SEARCH_KEY=YOUR_SEARCH_API_KEY
```

#### Create Indexes
In Algolia dashboard, create 3 indexes:
1. **blog** - For blog posts
2. **projects** - For projects
3. **services** - For services

#### API Endpoints
- `GET /api/search?q=search_term&limit=10&type=all`
  - Returns: Array of results
  - Types: blog, project, service, all

#### Test Locally
```bash
# 1. Setup indexes in Algolia dashboard

# 2. Index sample content
curl -X POST http://localhost:3000/api/admin/blog \
  -H "Authorization: Bearer ADMIN_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"title":"Test Post","slug":"test","content":"..."}'

# 3. Search
curl "http://localhost:3000/api/search?q=test&limit=10"

# 4. Check Algolia dashboard for indexed items
```

#### Client-Side Integration
```typescript
// Install in frontend
npm install algoliasearch instantsearch.js

// Usage
import algoliasearch from 'algoliasearch/lite';

const searchClient = algoliasearch(
  process.env.NEXT_PUBLIC_ALGOLIA_APP_ID,
  process.env.NEXT_PUBLIC_ALGOLIA_SEARCH_KEY
);
```

---

## 3️⃣ **Sentry Error Tracking**

### What is Sentry?
Automatically capture and report errors in production.

### Setup Steps

#### Get DSN
1. Go to https://sentry.io/
2. Sign up for free account
3. Create new Next.js project
4. Get your DSN (looks like: `https://xxx@yyy.ingest.sentry.io/zzz`)

#### Install Dependencies
```bash
npm install @sentry/nextjs
npx @sentry/wizard@latest -i nextjs
```

#### Environment Variables
Add to `.env.production`:
```env
# Sentry Error Tracking
SENTRY_DSN=https://xxx@yyy.ingest.sentry.io/zzz
SENTRY_ENVIRONMENT=production
```

#### Initialize in Root Layout
Update `src/app/layout.tsx`:
```typescript
import { initializeSentry } from '@/lib/sentry'

// Call on app startup
if (typeof window === 'undefined') {
  initializeSentry()
}
```

#### API Endpoints & Features
- Automatic error capture
- Performance monitoring
- User context (track which user had error)
- Breadcrumbs (track user actions before error)

#### Test Locally
```bash
# 1. Set SENTRY_DSN in .env.local
# SENTRY_DSN=your_dsn_here

# 2. Start app
npm run build && npm run start

# 3. Trigger test error
# In development, errors won't be sent to Sentry
# In production, they will be automatically captured

# 4. Check Sentry dashboard
```

#### Features to Monitor
- Authentication failures
- Payment errors
- Database query errors
- Unhandled exceptions
- API timeouts

---

## 4️⃣ **Swagger API Documentation**

### What is Swagger?
Interactive API documentation that developers can test directly in browser.

### Setup Steps

#### File Already Created
- `src/lib/api-documentation.ts` - OpenAPI schema
- `src/app/api/docs/route.ts` - Swagger UI endpoint

#### Access Documentation
Documentation is available at: `https://yourdomain.com/api/docs`

#### Update Documentation
Edit `src/lib/api-documentation.ts` to add new endpoints:

```typescript
'/api/new-endpoint': {
  post: {
    tags: ['Category'],
    summary: 'Endpoint description',
    requestBody: { /* schema */ },
    responses: { /* responses */ },
  },
}
```

#### Test Locally
```bash
# 1. Start app
npm run dev

# 2. Open browser
# http://localhost:3000/api/docs

# 3. Explore and test endpoints interactively
```

#### Benefits
- Auto-generated documentation
- No manual docs needed
- Developers can test API directly
- OpenAPI standard (compatible with many tools)

---

## 5️⃣ **New Relic Performance Monitoring**

### What is New Relic?
Application Performance Monitoring to track response times, errors, and resource usage.

### Setup Steps

#### Get License Key
1. Go to https://newrelic.com/
2. Sign up for free account (14-day free trial)
3. Create new application
4. Get License Key from settings

#### Install Dependencies
```bash
npm install newrelic
```

#### Create newrelic.js Config
Create `newrelic.js` in project root:
```javascript
'use strict'

exports.config = {
  app_name: ['Uptix Digital Agency'],
  license_key: process.env.NEW_RELIC_LICENSE_KEY,
  logging: {
    level: 'info',
  },
  error_collector: {
    enabled: true,
  },
  transaction_tracer: {
    enabled: true,
  },
}
```

#### Import at App Startup
Add to `server.ts` or `next.config.js`:
```javascript
require('newrelic');
```

#### Environment Variables
Add to `.env.production`:
```env
# New Relic APM
NEW_RELIC_LICENSE_KEY=YOUR_LICENSE_KEY
NEW_RELIC_APP_NAME=Uptix Digital Agency
```

#### Test Locally
```bash
# 1. Set NEW_RELIC_LICENSE_KEY in .env.production

# 2. Build and start
npm run build
npm run start

# 3. Make some requests to generate data
# curl http://localhost:3000

# 4. Check New Relic dashboard after 5-10 minutes
```

#### Metrics to Monitor
- **Apdex Score** (application performance)
- **Response Time** (average, P95, P99)
- **Throughput** (requests per minute)
- **Error Rate** (errors per minute)
- **CPU & Memory** (resource usage)

---

## 🧪 **Testing All Enhancements**

### Local Testing Checklist

#### 1. Build and Start App
```bash
npm run build
npm run dev
```

#### 2. Test 2FA
```bash
# Get auth token first
# Then test endpoints
curl -X POST http://localhost:3000/api/user/two-factor/setup \
  -H "Authorization: Bearer TOKEN"
```

#### 3. Test Algolia Search
```bash
# Verify search works
curl "http://localhost:3000/api/search?q=test"

# Check if Algolia library is installed
npm list algoliasearch  # Should show success or error
```

#### 4. Test Sentry
```bash
# Sentry DSN should be in env
echo $SENTRY_DSN

# Errors will be captured in production
# Test in development mode won't send to Sentry
```

#### 5. Test Swagger Docs
```bash
# Open in browser
# http://localhost:3000/api/docs

# Should see interactive API documentation
```

#### 6. Test New Relic
```bash
# Check if newrelic.js exists
ls -la newrelic.js

# Monitor dashboard
# Should start showing data after a few requests
```

---

## 📦 **Package Requirements Summary**

### All Dependencies to Install
```bash
# 2FA
npm install speakeasy qrcode

# Algolia Search
npm install algoliasearch

# Sentry
npm install @sentry/nextjs

# New Relic
npm install newrelic

# All TypeScript types
npm install --save-dev @types/speakeasy @types/algoliasearch
```

### Total New Packages: 4 main + 2 type definitions

---

## ✅ **Checklist for Production**

### Before Deploying Each Enhancement

**2FA/MFA**
- [ ] Install dependencies
- [ ] Update Prisma schema
- [ ] Run migrations
- [ ] Test with authenticator app
- [ ] Setup backup code recovery

**Algolia**
- [ ] Create free/paid Algolia account
- [ ] Create 3 indexes (blog, projects, services)
- [ ] Add API keys to env vars
- [ ] Index existing content
- [ ] Test search functionality
- [ ] Setup autocomplete (optional)

**Sentry**
- [ ] Create Sentry account
- [ ] Create Next.js project
- [ ] Add DSN to env vars
- [ ] Run in production for accuracy
- [ ] Setup alerts and thresholds
- [ ] Configure team notifications

**Swagger**
- [ ] Update documentation for all endpoints
- [ ] Test interactive testing
- [ ] Verify schema validity
- [ ] Add security definitions if needed
- [ ] Document all response codes

**New Relic**
- [ ] Create New Relic account
- [ ] Get license key
- [ ] Create newrelic.js config
- [ ] Add to app startup
- [ ] Monitor dashboard
- [ ] Setup custom alerts

---

## 🔗 **Integration Testing**

### End-to-End Test
```bash
# 1. Start app
npm run build && npm run start

# 2. Run test suite
npm run test

# 3. Generate load for monitoring
npm install -g artillery
artillery quick --count 100 --num 10 http://localhost:3000

# 4. Check all dashboards
# - Sentry: https://sentry.io
# - Algolia: https://www.algolia.com/apps
# - New Relic: https://one.newrelic.com
# - Swagger: http://localhost:3000/api/docs
```

---

## 📞 **Support & Troubleshooting**

### 2FA Issues
```bash
# Test TOTP token generation
node -e "const speakeasy = require('speakeasy'); console.log(speakeasy.totp({secret: 'TEST'}))"
```

### Algolia Issues
```bash
# Check if client initialized
npm run dev 2>&1 | grep -i algolia

# Verify API keys
curl -H "X-Algolia-API-Key: YOUR_KEY" https://YOUR_APP_ID.algolia.net/1/indexes
```

### Sentry Issues
```bash
# Verify DSN format
echo $SENTRY_DSN

# Test error capture
# Trigger error in production build
```

### New Relic Issues
```bash
# Check newrelic.js
head newrelic.js

# Verify license key
echo $NEW_RELIC_LICENSE_KEY | wc -c  # Should be ~40 chars
```

---

## 🎓 **Best Practices**

1. **Start Simple**: Enable one enhancement at a time
2. **Test Locally**: Verify each works before production
3. **Monitor**: Set up dashboards and alerts
4. **Document**: Update API documentation as you go
5. **Backup**: Keep database backups before migrations
6. **Scale**: These services auto-scale based on usage

---

**All enhancements are optional but recommended for production!** 🚀
