# 🔧 Deployment & Database Migration Guide

## Quick Start Checklist

### Before Deployment
- [ ] All environment variables configured
- [ ] Database backup taken
- [ ] Code coverage tested
- [ ] Build succeeds without errors
- [ ] No console warnings/errors in dev

### Database Changes
This deployment includes schema changes (new AuditLog table and indexes).

## Step-by-Step Deployment Guide

### 1. Local Preparation

```bash
# Pull latest code
git pull origin main

# Install dependencies (if any new packages)
npm install

# Create database migration
npx prisma migrate dev --name add_audit_logging_and_indexes

# This will:
# - Create migration files in prisma/migrations/
# - Apply changes to local database
# - Generate Prisma client
```

### 2. Test Locally

```bash
# Build for production
npm run build

# Start production server
npm run start

# Test critical flows:
# - User registration
# - User login
# - Contact form submission
# - Blog post creation
# - Payment flow
```

### 3. Deploy to Production

#### Option A: Vercel Deployment (Recommended)

```bash
# Commit changes
git add -A
git commit -m "feat: security and performance improvements"
git push origin main

# Vercel auto-deploys from main branch
# No additional steps needed if environment variables are set
```

#### Option B: Manual Deployment

```bash
# For Docker/self-hosted
npm run build
npm run start

# Or for serverless (AWS Lambda, Google Cloud Run)
# Build and deploy container
npm run build
# Deploy 'dist' or 'build' folder
```

### 4. Database Migration in Production

**Important**: Always backup database before migrations!

```bash
# Option 1: Vercel environment (recommended)
# Use Vercel dashboard to run commands:
# Settings → Functions → Add environment
vercel env pull  # Get production env vars
npx prisma migrate deploy  # Run migrations

# Option 2: SSH to server
ssh user@your-server.com
cd /app
npx prisma migrate deploy

# Option 3: Using Vercel CLI
vercel env pull .env.production.local
npx prisma migrate deploy --skip-generate
```

### 5. Verify Deployment

```bash
# Check application is running
curl https://yourdomain.com

# Verify database migrations applied
# Check if new tables exist
SELECT * FROM "AuditLog" LIMIT 1;

# Verify indexes created
SELECT indexname FROM pg_indexes WHERE tablename = 'User';

# Test critical APIs
curl -X POST https://yourdomain.com/api/contact \
  -H "Content-Type: application/json" \
  -d '{"name":"Test","email":"test@example.com","message":"Test message"}'
```

---

## Environment Variables Configuration

### Production (.env.production)

```env
# Database
DATABASE_URL="postgresql://user:password@host:5432/db"
DIRECT_URL="postgresql://user:password@host:5432/db"

# NextAuth
NEXTAUTH_URL="https://yourdomain.com"
NEXTAUTH_SECRET="<generate-32-char-random-string>"

# OAuth
GOOGLE_CLIENT_ID="your-client-id.apps.googleusercontent.com"
GOOGLE_CLIENT_SECRET="your-secret"

# Email
RESEND_API_KEY="re_xxxxxxxx"
ADMIN_EMAIL="admin@yourdomain.com"
FROM_EMAIL="noreply@yourdomain.com"
FROM_NAME="Your Company"

# CORS
ALLOWED_ORIGINS="https://yourdomain.com,https://www.yourdomain.com"
NEXT_PUBLIC_APP_URL="https://yourdomain.com"

# App
SITE_NAME="Your Site"
SITE_DESCRIPTION="Your description"
NODE_ENV="production"

# Payment (configure based on your provider)
STRIPE_PUBLIC_KEY="pk_live_xxx"
STRIPE_SECRET_KEY="sk_live_xxx"
STRIPE_WEBHOOK_SECRET="whsec_xxx"

# Analytics
GOOGLE_ANALYTICS_ID="G-XXXXXXXXXX"
ENABLE_ANALYTICS="true"
```

### Generating NEXTAUTH_SECRET

```bash
# Generate cryptographically secure random string (32+ chars)
openssl rand -base64 32

# Or use Node.js
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

---

## Rollback Plan

If something goes wrong:

### Vercel
```bash
# Rollback to previous deployment
vercel rollback
```

### Manual Deployment
```bash
# Rollback database
npx prisma migrate resolve --rolled-back add_audit_logging_and_indexes

# Or restore from backup
psql -U user -d database < backup.sql

# Revert code to previous version
git revert HEAD
git push
```

---

## Post-Deployment Checklist

### Day 1
- [ ] Monitor error logs (check Sentry if configured)
- [ ] Verify email sending works
- [ ] Test user registration flow
- [ ] Test login with different providers
- [ ] Test contact form (check rate limiting)
- [ ] Monitor database performance
- [ ] Check API response times

### Week 1
- [ ] Review error reports
- [ ] Check audit logs for suspicious activity
- [ ] Monitor database disk usage
- [ ] Test payment flow with live credentials
- [ ] Verify email verification system
- [ ] Monitor CORS errors
- [ ] Check rate limiting effectiveness

### Ongoing
- [ ] Setup automated daily backups
- [ ] Monitor database indexes are being used
- [ ] Review audit logs weekly
- [ ] Check security headers with https://securityheaders.com
- [ ] Monitor Core Web Vitals
- [ ] Update dependencies monthly

---

## Troubleshooting

### Issue: Prisma Migration Failed

```bash
# Check migration status
npx prisma migrate status

# If stuck, resolve manually
npx prisma migrate resolve --rolled-back migration_name

# Or skip problematic migration
npx prisma migrate deploy --skip-generate
```

### Issue: Rate Limiting Not Working

- Ensure `x-forwarded-for` header is being forwarded by proxy
- Check IP address detection in `getClientIP()`
- Monitor rate limit logs

### Issue: Email Not Sending

```bash
# Test Resend API key
curl -X POST https://api.resend.com/emails \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"from":"test@example.com","to":"you@example.com","html":"test"}'

# Check email configuration
# Verify RESEND_API_KEY, FROM_EMAIL, ADMIN_EMAIL
```

### Issue: CORS Errors

- Verify `ALLOWED_ORIGINS` includes your domain
- Check if domain is with/without `www`
- Ensure both variants are listed if needed

### Issue: 404 on New Routes

- Run build again: `npm run build`
- Clear Next.js cache: `rm -rf .next`
- Redeploy

---

## Performance Tuning Post-Deployment

### Database
```sql
-- Analyze query performance
EXPLAIN ANALYZE SELECT * FROM "Order" WHERE "userId" = 'xxx';

-- Check index usage
SELECT schemaname, tablename, indexname, idx_scan
FROM pg_stat_user_indexes
ORDER BY idx_scan DESC;

-- Update statistics
ANALYZE;
```

### Application
- Enable Vercel Analytics for Core Web Vitals
- Use Vercel's built-in monitoring
- Monitor database connection pool usage
- Review slowest API endpoints

### Caching
- Configure ISR for blog posts (revalidate: 3600)
- Use Vercel's Edge Caching
- Enable image optimization caching

---

## Monitoring & Maintenance

### Weekly
```bash
# Check database size
SELECT pg_size_pretty(pg_database_size('database_name'));

# Review recent errors
# (Setup Sentry for automated alerts)

# Check deployment status
vercel list
```

### Monthly
```bash
# Clean up old audit logs
# Run cleanup function or scheduled job
npx prisma studio
# Execute:
# await prisma.auditLog.deleteMany({
#   where: { createdAt: { lt: new Date(Date.now() - 90*24*60*60*1000) } }
# })

# Update dependencies
npm outdated
npm update
```

---

## Security Hardening Post-Deployment

```bash
# Verify security headers
curl -I https://yourdomain.com

# Should include:
# X-Content-Type-Options: nosniff
# X-Frame-Options: DENY
# X-XSS-Protection: 1; mode=block
# Referrer-Policy: strict-origin-when-cross-origin

# Check SSL/TLS configuration
openssl s_client -connect yourdomain.com:443

# Run security scan
# https://securityheaders.com
# https://www.ssllabs.com/ssltest/
```

---

## Backup & Disaster Recovery

### Automated Backups (Supabase)
If using Supabase:
- Backups are automatic (daily)
- 7-day retention by default
- Can restore from backup in dashboard

### Manual Backup
```bash
# PostgreSQL backup
pg_dump -h host -U user -d database > backup.sql

# Compress backup
gzip backup.sql

# Store securely (S3, etc)
aws s3 cp backup.sql.gz s3://bucket/backups/
```

### Restore from Backup
```bash
# Restore database
psql -U user -d database < backup.sql

# Or for compressed
gunzip -c backup.sql.gz | psql -U user -d database
```

---

## Common Commands Reference

```bash
# Build
npm run build
npm run start

# Database
npx prisma migrate dev
npx prisma migrate deploy
npx prisma studio

# Prisma Client
npx prisma generate

# Cleanup
rm -rf node_modules
npm install
npm run clean && npm run build
```

---

**Deployment Complete!** 🎉

Your application is now running with:
- ✅ Security hardening
- ✅ Rate limiting
- ✅ Audit logging
- ✅ XSS protection
- ✅ Database optimization
- ✅ Image optimization
- ✅ HTTPS enforcement
- ✅ Security headers

Monitor logs and address any issues immediately.
